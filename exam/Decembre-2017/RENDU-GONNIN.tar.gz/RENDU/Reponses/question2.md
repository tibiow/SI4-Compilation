REPONSES A LA QUESTION 2 (TRY-CATCH)
==============================================

Consignes:
  - Essayez de ne pas trop modifier la stucture de ce fichier
  - Vous pouvez copier/coller les parties *significatives* de vos
    modifications (ne copiez des fichiers entiers!!!)
  - le code c'est bien, mais s'il est expliqué c'est mieux.


Sous-question 1: Principales modifications du compilateur
---------------------------------------------------------

Ici une partie du travail est déja fait.
Entre autre le lexical et le syntaxique sont déja bon et n'ont pas à être touché.
De même l'ast est bien généré.
Il me faut faire l'analyse de try et throw ainsi que la production de leur code.





Sous-question 2: Exception non attrapée
---------------------------------------

Pour éviter ce problème, le compilateur doit faire en sorte que l'utiisation de throw se fasse hors d'un scope.





Sous-question 3: Fichier(s) modifiés
------------------------------------


### lexical.l: (indiquer 'PAS DE MODIFICATION' si le fichier n'est pas modifié)
_______________________________________________________________________________


'PAS DE MODIFICATION'




### syntax.y:  (indiquer 'PAS DE MODIFICATION' si le fichier n'est pas modifié)
_______________________________________________________________________________

'PAS DE MODIFICATION'





### ast.c/ast.h:  (indiquer 'PAS DE MODIFICATION' si le fichier n'est pas modifié)
_______________________________________________________________________________


'PAS DE MODIFICATION'




### analysis.c:  (indiquer 'PAS DE MODIFICATION' si le fichier n'est pas modifié)
_______________________________________________________________________________


Pour le try:


pour le throw:




### prodcode.c:  (indiquer 'PAS DE MODIFICATION' si le fichier n'est pas modifié)
_______________________________________________________________________________



Pour le try:



pour le throw:





### Modifications dans le runtime? (indiquer 'PAS DE MODIFICATION' si non modifié)
_______________________________________________________________________________







### Autres modifications? (indiquer 'PAS DE MODIFICATIONS' dans le cas contraire)
_______________________________________________________________________________



'PAS DE MODIFICATION'

