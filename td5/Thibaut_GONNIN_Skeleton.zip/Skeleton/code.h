/*
 * code.h 	-- Prioduction of code
 *
 * Copyright © 2015 Erick Gallesio - I3S-CNRS/Polytech Nice-Sophia <eg@unice.fr>
 *
 *           Author: Erick Gallesio [eg@unice.fr]
 *    Creation date: 21-Oct-2015 13:17 (eg)
 * Last file update:  4-Nov-2015 16:50 (eg)
 */

#ifndef _CODE_H_
#define _CODE_H_

void produce_code(ast_node *node);

#endif /* _CODE_H_ */
